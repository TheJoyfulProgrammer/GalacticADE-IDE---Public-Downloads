# BASIC Knowledge Base

This is the starter GalacticADE language-reference document for BASIC-family languages.

## Purpose

A language package may replace or extend this reference with QB64, QuickBASIC, CosmicQB, FreeBASIC, or another BASIC dialect.

```basic
PRINT "Hello from GalacticADE!"
```

The Knowledge Base is read-only and includes its own minimap so large manuals remain easy to navigate.
