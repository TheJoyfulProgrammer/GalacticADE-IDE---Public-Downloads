# C++ Knowledge Base

This is the starter GalacticADE language-reference document for C++.

## Purpose

Language packages can provide specialized Markdown reference material that GalacticADE displays in the read-only **Knowledge Base** editor.

## Example

```cpp
#include <iostream>

int main() {
    std::cout << "Hello from GalacticADE!\n";
    return 0;
}
```

Future language integration can map keywords, compiler diagnostics, library symbols, and context-sensitive help directly to sections in this knowledge base.
