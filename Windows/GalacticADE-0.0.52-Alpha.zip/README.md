# GalacticADE

Current integration: **GalacticADE 0.0.52-Alpha / CosmicGUI 0.1.45**

## Package

- GalacticADE: `0.0.52-Alpha`
- CosmicGUI: `0.1.45`
- CTF baseline: M00P08 integration
- Windows toolchain target: MSYS2 CLANG64 + LLVM/Clang + CMake + Ninja
- Rendering: SDL3 + Vulkan

Package folder and ZIP name:

`GalacticADE-0.0.52-Alpha/` inside `GalacticADE-0.0.52-Alpha.zip`

## 

Telemetry is off by default. Start with either `--TEL` or `--TELEMETRY` to enable the existing performance/resource instrumentation and debug/report output for that process. Use `--?` or `--HELP` for identical console help and exit. Help takes precedence over telemetry and opens no application window.

```bat
./GalacticADE.exe
./GalacticADE.exe --TEL
./GalacticADE.exe --TELEMETRY
./GalacticADE.exe --HELP
./GalacticADE.exe --?
```

The flags are case-sensitive. Telemetry-off launches skip the sampler thread, platform resource queries, telemetry-only CPU timers and counters, event formatting, Vulkan timestamp queries, GPU allocation tracking and debug/report generation. Animation clocks, syntax publication budgets, document indexes and normal editor behavior remain active. Performance-test shortcuts require a telemetry-enabled launch; they cannot turn collection on implicitly.

The existing telemetry columns, event formats and measurements are preserved. The legacy `Correction` metadata field now reads `none`; releases use only their version and channel. No correction identifier or extension version appears in the new package name. Historical notes below retain their original identifiers.

## Event-aware diagnostics

The raw debug log now marks and/or classifies important workloads independently, including document activation, window resize/maximize, display-scale changes, font changes, panel visibility changes, mouse-wheel scrolling, physical PageDown activity, and minimap dragging. Minimap drag begin/end markers include the visible line.

This prevents setup and random minimap scrubbing from being mixed with the sequential PageDown benchmark.

### Built-in synthetic PageDown/PageUp benchmark

Press:

`Ctrl+Alt+Shift+P`

GalacticADE will:

1. save the current caret and viewport;
2. place the caret at the first line before its first character and scroll to the top;
3. invoke the editor's real internal PageDown path once per frame, without synthesizing SDL key events, until the last line is reached;
4. invoke PageUp once per frame until line 1 is reached;
5. repeat for five complete down/up cycles;
6. restore the user's original caret and viewport.

Cycle 1 naturally represents a colder-cache run while cycles 2–5 measure warm sustained behavior. Press `Esc` to abort. Ordinary editor input is ignored while an automatic benchmark is running.

### Built-in minimap benchmark

Press:

`Ctrl+Alt+Shift+M`

The test has three separately reported phases:

1. **Deterministic random access — 10 seconds.** A fixed seed and shuffled 256-band document distribution produce reproducible nonlocal jumps with a target minimum distance of 10% of the document.
2. **Continuous scrub — five top-to-bottom/bottom-to-top cycles.** Each leg uses 96 steps to exercise realistic incremental minimap dragging and retained-ring reuse.
3. **Adversarial bounce — 5 seconds.** Repeated long-distance targets such as top/bottom, 25%/75%, 10%/90%, and near-end positions stress cache boundaries and random-access lookup.

The benchmark drives the same internal minimap scrolling path but does not create fake mouse events. The user's original caret and viewport are restored afterward.

### Automatic Markdown report at shutdown

On normal application shutdown, GalacticADE first flushes/closes the raw `.txt` telemetry stream and then generates a companion Markdown report:

`Debug-GalacticADE-DateYMD_YYYYMMDD-TimeHMS_HHMMSS-Report.md`

The report defines:

- **Low** = P10
- **Medium** = arithmetic mean
- **Median** = P50
- **High** = P95
- **Peak** = maximum

It includes system/test configuration, per-document comparisons, resource use by event class, a dedicated minimap section, a dedicated PageDown/PageUp section, per-cycle synthetic page throughput tables, per-phase minimap throughput tables, recorded benchmark markers, measured accomplishments, and measurement-driven optimization opportunities.

The raw `.txt` remains the frame-by-frame forensic source; the `.md` is the human-readable engineering/marketing summary.


