# Fonts

Cosmic GUI packages these runtime fonts:

- `Ubuntu-Medium.ttf` — the global user-interface face (`Cosmic UI`).
- `Inconsolata-Regular.ttf` — the default `TextEditor8` / ASCII-Markdown editor
  face. M00P01C16 defaults to **14 px**.
- `RedditMono-Regular.ttf` — selectable monospaced editor face.
- `UbuntuMono-Regular.ttf` — selectable monospaced editor face.
- `Ac437_IBM_PGC.ttf`, `Ac437_IBM_VGA_8x14.ttf`, `Ac437_IBM_VGA_8x16.ttf`,
  `Ac437_IBM_VGA_9x14.ttf`, `Ac437_IBM_VGA_9x16.ttf`, `Ac437_IBM_VGA_9x8.ttf`,
  `Ac437_IGS_VGA_8x16.ttf`, and `Ac437_IGS_VGA_9x16.ttf` — selectable CP437
  faces for DOS/ASCII-style material.

CMake copies the whole `assets/fonts` directory beside the executable, so the
font list is available without a separate install step. Editor font selection is
exposed from the workbench **Settings** menu; Ctrl+mouse-wheel continues to
change the active editor size.

The Inconsolata and Reddit Mono license/readme files supplied with the uploaded
font archive are preserved under `assets/fonts/licenses/`.
